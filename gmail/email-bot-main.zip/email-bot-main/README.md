# email-bot

Simple AI email bot with OpenAI and Simplegmail

0. git clone
1. setup gmail API 
2. create desktop OAuth2 credentials
3. download JSON, move it into directory
4. rename JSON to client_secrets.json
5. pip install -r requirements.txt
6. export OPENAI_API_KEY="your-api-key"
7. python email_bot.py
